﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace Projekt_PAD_2
{
    public partial class Home : UserControl
    {

        
        public Home()
        {

            InitializeComponent(); 
            search s = new search();
            s.XD("Select Nazwa, Miasto, Kierunki, Ocena FROM szkola");
            //na starcie daje wszystkie szkoły
            ListViewItem i = new ListViewItem();
            for (int j = 0; j < Class1.item.Count; j++)
            {
                
                i = Class1.item[j];
                listView1.Items.Add(i);
            }


        }
        
       

            
        

        /*public Home(string nazwa_profilu)
        {
            InitializeComponent();
            label2.Text = nazwa_profilu;
            
        }*/
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //klikasz na nazwe szkoły i ci się tutaj mapka odpala
            if (listView1.SelectedItems.Count >= 1)
            {
                ListViewItem item = listView1.SelectedItems[0];

                //here i check for the Mouse pointer location on click if its contained 
                // in the actual selected item's bounds or not .
                // cuz i ran into a problem with the ui once because of that ..
                
                
                string miasto1 = item.SubItems[1].Text;
                try
                {

                    string queryadress = "https://www.google.pl/maps/place/";
                    if (miasto1 != String.Empty)
                    {
                        queryadress = ("https://www.google.pl/maps/place/" + miasto1);
                    }

                    webBrowser1.Navigate(queryadress);

                    


                }
                catch (Exception ex)
                {
                    MessageBox.Show(miasto1 + ex.Message);

                }

            }
        }

        


        private void ListView1_ItemActivate(Object sender, EventArgs e)
        {

            
        }
        
            
        


        private void button1_Click(object sender, EventArgs e)
        {
            // to odpowiada za wstawienie danych przez przycisk na home(prawy górny róg)
            listView1.Items.Clear();
            ListViewItem i = new ListViewItem();
            for (int j = 0; j < Class1.item.Count; j++)
            {
                i = Class1.item[j];
                listView1.Items.Add(i);
            }

        }

        public void label2_Click(object sender, EventArgs e)
        {

        }

        private void Home_Load(object sender, EventArgs e)
        {
        }

        private void siticoneTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void siticoneTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            int OLECMDID_OPTICAL_ZOOM = 63;
            int OLECMDEXECOPT_DONTPROMPTUSER = 2;
            dynamic iwb2 = webBrowser1.ActiveXInstance;
            object zoom = 60; //The value should be between 10 , 1000
            iwb2.ExecWB(OLECMDID_OPTICAL_ZOOM, OLECMDEXECOPT_DONTPROMPTUSER, zoom, zoom);
        }

        
    }
}
