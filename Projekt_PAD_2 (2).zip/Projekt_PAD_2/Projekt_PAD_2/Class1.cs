﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace Projekt_PAD_2
{
    public class Class1
    {
        string str = "server=localhost;database=szkoly;userid=root;password=''";
        public static string NP { get; set; }
        public static string miasto { get; set; }
        //tu na dole tez nie potrzebne XD
        public static string komenda1 { get; set; }
        //l jest niepotrzebne 
        public static ListView l { get; set; }


        public static List<ListViewItem> item { get; set; }

       


    }
}
